package com.example.meuapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val edtMensagem = findViewById<EditText>(R.id.edtMensagem)
        val txtLogin = findViewById<TextView>(R.id.txtLoguin)
        val btnCliqueAqui = findViewById<Button>(R.id.btnCliqueAqui)
        btnCliqueAqui.setOnClickListener {
        txtLogin.text = edtMensagem.text.toString()
        }

    }
}